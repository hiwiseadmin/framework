<?php
/**
 * 演示插件公共函数
 * 为避免插件函数名冲突，所有插件函数名前都添加了插件名前缀
 */

if (!function_exists('demo_hello_world')) {
    function demo_hello_world($name = 'World')
    {
        return "Hello {$name} from Demo Plugin!";
    }
}

if (!function_exists('demo_get_config')) {
    function demo_get_config($key = null, $default = null)
    {
        $config = \think\facade\Config::get('demo', []);
        
        if ($key === null) {
            return $config;
        }
        
        return $config[$key] ?? $default;
    }
}