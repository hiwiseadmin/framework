<?php
/**
 * 演示插件路由定义
 */

use think\facade\Route;

// 前台路由
// Route::group('', function () {
    // 演示页面
    // Route::get('demo', 'index/index');
    
    // API接口
    // Route::group('api/demo', function () {
    //     Route::get('info', 'api/getInfo');
    //     Route::post('submit', 'api/submit');
    // });
// })->middleware(['demo.auth']);

// 后台路由
// Route::group('admin/demo', function () {
//     Route::get('', 'admin.index/index');
//     Route::get('config', 'admin.config/index');
//     Route::post('config/save', 'admin.config/save');
// })->middleware(['demo.auth', 'admin']);