<?php
namespace plugin\demo\controller;

use app\common\plugin\BaseController;

class Index extends BaseController
{
    protected $noNeedLogin      = [];//无需登录，也无需鉴权的方法名列表，支持*通配符定义所有方法
    protected $noNeedAuth       = [];//需要登录，但是无需鉴权的方法名列表，支持*通配符定义所有方法
    protected $noNeedSelfAuthId = [];//不需要鉴别自己权限的角色ID

    public function index()
    {
        // 获取插件配置
        $config = $this->getPluginConfig();

        // 生成插件内部URL
        $userUrl = $this->pluginUrl('user/profile');
        $apiUrl = $this->pluginUrl('api/user/get');
        $helloUrl = $this->pluginUrl('hello');

        return $this->assign([
            'title' => 'Demo插件首页',
            'config' => $config,
            'user_url' => $userUrl,
            'api_url' => $apiUrl,
            'hello_url' => $helloUrl,
            'welcome' =>$this->request->param('name', '访客')
        ])->fetch('index/index');
    }
    
    public function hello($name = 'World')
    {
        return $this->fetch('hello', [
            'name' => $name,
            'message' => "Hello {$name}, 欢迎使用Demo插件!"
        ]);
    }
    
    public function apiTest()
    {
        return json([
            'code' => 1,
            'msg' => '成功',
            'data' => [
                'plugin' => $this->pluginName,
                'time' => date('Y-m-d H:i:s'),
                'config' => $this->getPluginConfig('api', [])
            ]
        ]);
    }
}