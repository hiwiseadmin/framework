<?php
namespace plugin\demo;

use app\common\plugin\BasePlugin;

class Plugin extends BasePlugin
{
    protected $name;
    protected $title;
    protected $version;
    protected $author;
    protected $description;

    /**
     * 安装插件
     * @return bool
     */
    public function install()
    {
        // $ret = $this->runSqlFile('install.sql');
        return $ret;
    }
    
    /**
     * 卸载插件
     * @return bool
     */
    public function uninstall()
    {
        // $ret = $this->runSqlFile('uninstall.sql');
        return $ret;
    }
        
    /**
     * 启用插件
     * @return bool
     */
    public function enable()
    {
        return true;
    }
    
    /**
     * 禁用插件
     * @return bool
     */
    public function disable()
    {
        return true;
    }

    /**
     * 获取钩子配置
     * @return array
     */
    public function getHooks()
    {
        return [];
    }
}