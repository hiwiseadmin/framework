<?php
/**
 * 演示插件中间件定义
 */

// use plugin\demo\middleware\DemoAuth;

return [
    // 插件授权中间件
    'demo.auth' => DemoAuth::class,
    
    // 插件日志中间件
    'demo.log' => \plugin\demo\middleware\DemoLog::class,
];