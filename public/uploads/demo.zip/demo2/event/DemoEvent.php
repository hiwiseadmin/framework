<?php
namespace plugin\demo\event;

class DemoEvent
{
    /**
     * 用户登录事件处理
     */
    public function onUserLogin($user)
    {
        // 记录用户登录日志
        \think\facade\Log::info("用户登录: {$user['username']} - " . date('Y-m-d H:i:s'));
        
        // 可以在这里添加其他逻辑，如发送通知等
    }
    
    /**
     * 页面渲染前事件处理
     */
    public function onBeforeRender($data)
    {
        // 修改页面数据
        if (isset($data['title'])) {
            $data['title'] .= ' - Demo Plugin';
        }
        
        return $data;
    }
    
    /**
     * 插件加载完成事件处理
     */
    public function onPluginLoaded($pluginName)
    {
        if ($pluginName === 'demo') {
            \think\facade\Log::info('Demo插件已加载完成');
        }
    }
}