<?php
namespace plugin\demo\middleware;

use think\Request;
use think\Response;

class DemoAuth
{
    public function handle(Request $request, \Closure $next)
    {
        // 检查插件是否启用
        $plugin = \app\model\Plugin::where('name', 'demo')
            ->where('status', 1)
            ->find();
            
        if (!$plugin) {
            return redirect('/plugin/disabled?name=demo');
        }
        
        // 检查用户权限
        $token = $request->header('Authorization') ?? $request->param('token');
        
        if (!$this->checkToken($token)) {
            if ($request->isAjax()) {
                return json(['code' => 401, 'msg' => '未授权访问']);
            } else {
                return redirect('/user/login');
            }
        }
        
        // 添加插件标识到请求
        $request->plugin = 'demo';
        
        return $next($request);
    }
    
    /**
     * 检查令牌
     */
    protected function checkToken($token)
    {
        // 这里实现具体的令牌验证逻辑
        // 可以从数据库或缓存中验证
        
        return !empty($token);
    }
}