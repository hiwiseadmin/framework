<?php
return [
    'name' => 'demo',
    'title' => '演示插件',
    'description' => '这是一个演示插件',
    'author' => 'thinkphp',
    'version' => '1.0.0',
    'status' => 1,
    'config' => [
        'debug' => true,
    ],
];